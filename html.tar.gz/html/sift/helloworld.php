<!DOCTYPE html>
<html>
<body>

<?php
$txt = " e = ir";
$i = 0.25;
$r = 212;

echo $txt;
echo "<hr />";
echo $i;
echo "<br />";
echo $r;
echo "<br />";
$e = $i*$r;
echo $e
?>

</body>
</html>
