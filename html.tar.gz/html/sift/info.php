info.html
<?php
   phpinfo();
?>
