<?php
   $hostName = "localhost";
   $databaseName = "stream";
   $username = "webuser";
   $password = "changethis";
	
  	function clean($input, $maxlength)
 	{
     $input = substr($input, 0, $maxlength);
    $input = EscapeShellCmd($input);
   return ($input);
  }
?>
